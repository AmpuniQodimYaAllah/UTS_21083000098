package com.qodim.uts_qodim;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME= "data";
    private static final String TABLE_IDENTITAS = "identitas";
    private static final String KEY_NIK= "NIK";
    private static final String KEY_Nama_Lengkap = "namalengkap";
    private static final String KEY_Tanggal_Lahir = "tanggallahir";
    private static final String KEY_Tempat_Lahir = "tempatlahir";
    private static final String KEY_Alamat= "alamat";
    private static final String KEY_Usia= "usia";
    private static final String KEY_Jenis_Kelamin= "jeniskelamin";
    private static final String KEY_Kewarganegaraan= "kewarganegaraan";
    private static final String KEY_Bidang_Kompetensi= "bidangkompetensi";
    private static final String KEY_Email= "Email";

    SQLiteDatabase db;

    public DatabaseHandler(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String query = "CREATE TABLE " + TABLE_IDENTITAS + "("
                + KEY_NIK +" INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_Nama_Lengkap + " TEXT,"
                + KEY_Tanggal_Lahir + " INTEGER," // Tipe data INTEGER untuk tanggal lahir
                + KEY_Tempat_Lahir +" TEXT,"
                + KEY_Alamat +" TEXT,"
                + KEY_Usia + " TEXT," // Tipe data TEXT untuk usia
                + KEY_Jenis_Kelamin +" TEXT,"
                + KEY_Kewarganegaraan +" TEXT,"
                + KEY_Email +" TEXT)"; // Hapus koma di akhir sini
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        //drop table lama (jika ada)
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_IDENTITAS);
        // buat table lagi
        onCreate(db);
    }

    //untuk nambah
    public long tambahidentitas(String NIK, String namalengkap,String tanggallahir,String tempatlahir,String alamat,String usia,String kelamin,String kewarganegaraan,String email){
        db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NIK, NIK);
        values.put(KEY_Nama_Lengkap, namalengkap);
        values.put(KEY_Tanggal_Lahir, tanggallahir);
        values.put(KEY_Tempat_Lahir, tempatlahir);
        values.put(KEY_Alamat, alamat);
        values.put(KEY_Usia, usia);
        values.put(KEY_Jenis_Kelamin, kelamin);
        values.put(KEY_Kewarganegaraan, kewarganegaraan);
        values.put(KEY_Email, email);

        long result = db.insert(TABLE_IDENTITAS, null, values);
        db.close();

        return result;
    }


}
