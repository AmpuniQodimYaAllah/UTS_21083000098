package com.qodim.uts_qodim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TampilActivity extends AppCompatActivity {

    DatabaseHandler db;
    TextView textView;
    String data;

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampil);

        textView = findViewById(R.id.cekdata);
        button = findViewById(R.id.cekdua);
        db = new DatabaseHandler(this);

        // Mendapatkan data dari database dan menampilkannya di TextView
        data = db.tambahidentitas();
        textView.setText(data);

        // Mengatur onClickListener untuk tombol cekdua
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
