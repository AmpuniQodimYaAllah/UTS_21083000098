package com.qodim.uts_qodim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    DatabaseHandler db;
    EditText eNIK, enamalengkap, edatePicker, etempatlahir, ealamat, eusia, ekewarganegaraan, ekompetensi, eemail;
    Button bsubmit, breset, bcek;

    String NIK, namalengkap, datePicker, tempatlahir, alamat, usia, kewarganegaraan, kompetensi, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eNIK = findViewById(R.id.NIK);
        enamalengkap = findViewById(R.id.namalengkap);
        edatePicker = findViewById(R.id.datePicker);
        etempatlahir = findViewById(R.id.tempatlahir);
        ealamat = findViewById(R.id.alamat);
        eusia = findViewById(R.id.usia);
        ekewarganegaraan = findViewById(R.id.kewarganegaraan);
        ekompetensi = findViewById(R.id.kompetensi);
        eemail = findViewById(R.id.email);

        bsubmit = findViewById(R.id.submit);
        breset = findViewById(R.id.reset);
        bcek = findViewById(R.id.cek);

        bsubmit.setOnClickListener(this);
        breset.setOnClickListener(this);
        bcek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), TampilActivity.class);
                startActivity(intent);
            }
        });

        db = new DatabaseHandler(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.submit:
                NIK = eNIK.getText().toString();
                namalengkap = enamalengkap.getText().toString();
                datePicker = edatePicker.getText().toString();
                tempatlahir = etempatlahir.getText().toString();
                alamat = ealamat.getText().toString();
                usia = eusia.getText().toString();
                kewarganegaraan = ekewarganegaraan.getText().toString();
                kompetensi = ekompetensi.getText().toString();
                email = eemail.getText().toString();

                if (NIK.equals("")) {
                    Toast.makeText(this, "Tolong isi dengan benar", Toast.LENGTH_SHORT).show();
                } else {
                    long result = db.tambahidentitas(NIK, namalengkap, datePicker, tempatlahir, alamat, usia, kewarganegaraan, kompetensi, email);
                    if (result != -1) {
                        Toast.makeText(this, "Data telah tersimpan.", Toast.LENGTH_SHORT).show();
                        eNIK.setText("");
                        enamalengkap.setText("");
                        edatePicker.setText("");
                        etempatlahir.setText("");
                        ealamat.setText("");
                        eusia.setText("");
                        ekewarganegaraan.setText("");
                        ekompetensi.setText("");
                        eemail.setText("");
                    } else {
                        Toast.makeText(this, "Gagal menyimpan data.", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case R.id.reset:
                eNIK.setText("");
                enamalengkap.setText("");
                edatePicker.setText("");
                etempatlahir.setText("");
                ealamat.setText("");
                eusia.setText("");
                ekewarganegaraan.setText("");
                ekompetensi.setText("");
                eemail.setText("");
                break;
        }
    }
}
